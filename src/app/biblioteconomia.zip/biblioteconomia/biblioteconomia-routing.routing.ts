import { Routes, RouterModule } from '@angular/router';
import { AssuntosComponent } from './assuntos/assuntos.component';

const routes: Routes = [
  {
    path: '',
    component:AssuntosComponent
  },
];

export const BiblioteconomiaRoutingRoutes = RouterModule.forChild(routes);
