export interface Biblioteconomia {
  title: string,
  article: string,
  cols: number,
  rows: number,
}
